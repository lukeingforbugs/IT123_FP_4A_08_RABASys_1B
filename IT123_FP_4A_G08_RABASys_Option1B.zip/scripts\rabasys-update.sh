#!/bin/bash
# Purpose: Back up RABASys and its local database, apply an update, and verify health.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-update.sh UPDATE_SOURCE_DIR [--help]
# AI assistance: OpenAI Codex, backup flow, failure handling, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"
BACKUP_ARCHIVE=""

usage() {
    echo "Usage: sudo $0 UPDATE_SOURCE_DIR"
    echo "Creates a verified app/database backup, applies an update, and checks health."
    echo "Example: sudo $0 /home/student/rabasys-update"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

failure_with_restore() {
    echo "FAILURE: update was not verified." >&2
    echo "The backup was not restored automatically." >&2
    echo "Restore manually with these commands:" >&2
    echo "sudo systemctl stop rabasys-backend.service" >&2
    echo "sudo mkdir -p \"$APP_DIR\"" >&2
    echo "sudo tar -xzf \"$BACKUP_ARCHIVE\" -C \"$APP_DIR\" --strip-components=1 app" >&2
    echo "sudo bash -c 'source \"$CONFIG_FILE\"; tar -xOzf \"$BACKUP_ARCHIVE\" database.sql | PGPASSWORD=\"\$DB_PASS\" psql -h 127.0.0.1 -U \"\$DB_USER\" -d \"\$DB_NAME\"'" >&2
    echo "sudo chown -R \"$APP_USER:$APP_GROUP\" \"$APP_DIR\"" >&2
    echo "sudo systemctl start rabasys-backend.service" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this script as root"
[[ $# -eq 1 ]] || { usage >&2; exit 2; }

for required_command in systemctl stat tar pg_dump psql curl npm date install chown; do
    command -v "$required_command" >/dev/null 2>&1 \
        || fail "required command not found: $required_command"
done

[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"
# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"

: "${APP_DIR:?APP_DIR is required in the config}"
: "${BACKUP_DIR:?BACKUP_DIR is required in the config}"
: "${DB_NAME:?DB_NAME is required in the config}"
: "${DB_USER:?DB_USER is required in the config}"
: "${DB_PASS:?DB_PASS is required in the config}"
: "${HEALTH_URL:?HEALTH_URL is required in the config}"
: "${APP_USER:?APP_USER is required in the config}"
: "${APP_GROUP:?APP_GROUP is required in the config}"

UPDATE_SOURCE_DIR="$1"
[[ -d "$UPDATE_SOURCE_DIR" ]] || fail "update source directory not found: $UPDATE_SOURCE_DIR"
[[ -d "$APP_DIR" ]] || fail "application directory not found: $APP_DIR"

timestamp="$(date '+%Y%m%d-%H%M%S')"
BACKUP_ARCHIVE="${BACKUP_DIR}/rabasys-${timestamp}.tar.gz"
backup_stage="$(mktemp -d)" || fail "could not create temporary backup directory"
trap 'rm -rf "$backup_stage"' EXIT

install -d -m 750 -o root -g root "$BACKUP_DIR" \
    || fail "could not prepare backup directory"
install -d "$backup_stage/app" \
    || fail "could not prepare backup staging directory"

echo "Creating application backup..."
tar -cf - -C "$APP_DIR" . | tar -xf - -C "$backup_stage/app" \
    || fail "application backup failed"

echo "Creating local PostgreSQL dump..."
PGPASSWORD="$DB_PASS" pg_dump -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
    > "$backup_stage/database.sql" \
    || fail "database backup failed"

tar -czf "$BACKUP_ARCHIVE" -C "$backup_stage" app database.sql \
    || fail "compressed backup creation failed"
tar -tzf "$BACKUP_ARCHIVE" >/dev/null 2>&1 \
    || fail "backup integrity check failed"
echo "Verified backup: $BACKUP_ARCHIVE"

echo "Stopping the backend before applying the update..."
systemctl stop rabasys-backend.service \
    || fail "could not stop the backend"

echo "Copying update files..."
tar --exclude=node_modules --exclude=.env -cf - -C "$UPDATE_SOURCE_DIR" . \
    | tar -xf - -C "$APP_DIR" \
    || failure_with_restore

(cd "$APP_DIR/backend" && npm install) \
    || failure_with_restore
(cd "$APP_DIR/frontend" && npm install && npm run build) \
    || failure_with_restore

chown -R "$APP_USER:$APP_GROUP" "$APP_DIR" \
    || failure_with_restore
chmod 600 "$APP_DIR/backend/.env" \
    || failure_with_restore

systemctl start rabasys-backend.service \
    || failure_with_restore

if curl --fail --silent --show-error "$HEALTH_URL" >/dev/null; then
    echo "SUCCESS: update applied and health check passed"
    exit 0
else
    failure_with_restore
fi
