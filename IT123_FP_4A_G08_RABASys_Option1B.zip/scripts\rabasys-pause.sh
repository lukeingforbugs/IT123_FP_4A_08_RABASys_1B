#!/bin/bash
# Purpose: Pause or resume the RABASys backend process for lifecycle testing.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-pause.sh {pause|resume|--help}
# AI assistance: OpenAI Codex, process detection, state checks, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"

usage() {
    echo "Usage: sudo $0 {pause|resume}"
    echo "Commands:"
    echo "  pause    Suspend the backend process"
    echo "  resume   Continue the backend process"
    echo "  --help   Show this help message"
    echo "Example: sudo $0 pause"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this script as root"
[[ $# -eq 1 ]] || { usage >&2; exit 2; }

for required_command in pgrep ps kill stat; do
    command -v "$required_command" >/dev/null 2>&1 \
        || fail "required command not found: $required_command"
done

[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"
# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"
: "${APP_DIR:?APP_DIR is required in the config}"

find_backend_pid() {
    pgrep -f "$APP_DIR/backend/server.js" | head -n 1 || true
}

backend_pid="$(find_backend_pid)"
[[ -n "$backend_pid" ]] || fail "RABASys backend process was not found"

process_state() {
    ps -p "$backend_pid" -o stat= | tr -d ' '
}

case "$1" in
    pause)
        kill -STOP "$backend_pid" \
            || fail "could not pause backend PID $backend_pid"

        state="$(process_state)"
        if [[ "$state" =~ T ]]; then
            echo "PAUSED: backend PID $backend_pid has process state $state"
            exit 0
        fi
        fail "backend PID $backend_pid was not reported as stopped; state=$state"
        ;;
    resume)
        kill -CONT "$backend_pid" \
            || fail "could not resume backend PID $backend_pid"

        sleep 1
        state="$(process_state)"
        if [[ -n "$state" && ! "$state" =~ T ]]; then
            echo "RESUMED: backend PID $backend_pid has process state $state"
            exit 0
        fi
        fail "backend PID $backend_pid is still stopped; state=$state"
        ;;
    *)
        usage >&2
        exit 2
        ;;
esac
