#!/bin/bash
# Purpose: Start, stop, or restart RABASys services in dependency order.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-startstop.sh {start|stop|restart|--help}
# AI assistance: OpenAI Codex, script structure, validation, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"

usage() {
    echo "Usage: sudo $0 {start|stop|restart}"
    echo "Commands:"
    echo "  start    Start services in dependency order"
    echo "  stop     Stop services in reverse dependency order"
    echo "  restart  Stop and start all services"
    echo "  --help   Show this help message"
    echo "Example: sudo $0 start"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this script as root"
[[ $# -eq 1 ]] || { usage >&2; exit 2; }
command -v systemctl >/dev/null 2>&1 || fail "systemctl is required"
command -v ss >/dev/null 2>&1 || fail "ss is required"
command -v grep >/dev/null 2>&1 || fail "grep is required"
[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"

# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"
: "${APP_PORT:?APP_PORT is required in the config}"
: "${SERVICES:?SERVICES is required in the config}"

read -r -a SERVICE_LIST <<< "$SERVICES"
[[ "${#SERVICE_LIST[@]}" -gt 0 ]] || fail "SERVICES cannot be empty"

for service_name in "${SERVICE_LIST[@]}"; do
    systemctl cat "$service_name" >/dev/null 2>&1 \
        || fail "service does not exist: $service_name"
done

port_is_open() {
    ss -tlnp | grep -Eq ":${APP_PORT}([[:space:]]|$)" >/dev/null
}

app_is_running() {
    systemctl is-active --quiet "rabasys-backend.service" || port_is_open
}

start_services() {
    if app_is_running; then
        fail "RABASys is already running on port $APP_PORT"
    fi

    for service_name in "${SERVICE_LIST[@]}"; do
        systemctl start "$service_name"
        status_code=$?
        if [[ "$status_code" -ne 0 ]]; then
            fail "could not start $service_name; exit code $status_code"
        fi
        echo "Started $service_name"
    done
}

stop_services() {
    for ((index=${#SERVICE_LIST[@]} - 1; index>=0; index--)); do
        service_name="${SERVICE_LIST[index]}"
        systemctl stop "$service_name"
        status_code=$?
        if [[ "$status_code" -ne 0 ]]; then
            fail "could not stop $service_name; exit code $status_code"
        fi
        echo "Stopped $service_name"
    done
}

case "$1" in
    start)
        start_services
        ;;
    stop)
        stop_services
        ;;
    restart)
        stop_services
        start_services
        ;;
    *)
        usage >&2
        exit 2
        ;;
esac

echo "SUCCESS: command '$1' completed"
exit 0
