#!/bin/bash
# Purpose: Turn RABASys maintenance mode on, off, or show its status.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-maintenance.sh {on|off|status|--help}
# AI assistance: OpenAI Codex, Nginx maintenance design, validation, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"
NGINX_SITE="/etc/nginx/sites-available/rabasys"
MAINT_DIR="/var/www/rabasys/maintenance"

usage() {
    echo "Usage: sudo $0 {on|off|status}"
    echo "Commands:"
    echo "  on       Show the maintenance page and return HTTP 503"
    echo "  off      Return to the normal RABASys application"
    echo "  status   Show whether maintenance mode is active"
    echo "  --help   Show this help message"
    echo "Example: sudo $0 on"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this script as root"
[[ $# -eq 1 ]] || { usage >&2; exit 2; }

for required_command in systemctl nginx install rm stat; do
    command -v "$required_command" >/dev/null 2>&1 \
        || fail "required command not found: $required_command"
done

[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"
# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"

: "${APP_DIR:?APP_DIR is required in the config}"
: "${APP_PORT:?APP_PORT is required in the config}"
: "${MAINT_FLAG:?MAINT_FLAG is required in the config}"
: "${WEB_ROOT:?WEB_ROOT is required in the config}"

systemctl is-active --quiet nginx \
    || fail "nginx is not running"
[[ -f "$NGINX_SITE" ]] || fail "Nginx site was not found: $NGINX_SITE"

write_nginx_site() {
    cat > "$NGINX_SITE" <<EOF
server {
    listen 80 default_server;
    server_name _;
    root ${WEB_ROOT};
    index index.html;

    error_page 503 /maintenance.html;

    location = /maintenance.html {
        root ${MAINT_DIR};
        internal;
    }

    location /api/ {
        if (-f ${MAINT_FLAG}) { return 503; }
        proxy_pass http://127.0.0.1:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    location /uploads/ {
        if (-f ${MAINT_FLAG}) { return 503; }
        proxy_pass http://127.0.0.1:${APP_PORT};
    }

    location / {
        if (-f ${MAINT_FLAG}) { return 503; }
        try_files \$uri \$uri/ /index.html;
    }
}
EOF
}

case "$1" in
    on)
        install -d -m 755 "$MAINT_DIR" \
            || fail "could not create maintenance directory"
        cat > "$MAINT_DIR/maintenance.html" <<'HTML'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RABASys Maintenance</title>
  <style>body{font-family:Arial,sans-serif;text-align:center;margin:12vh auto;max-width:680px;color:#5c1d29}h1{font-size:2.2rem}p{font-size:1.1rem}</style>
</head>
<body>
  <h1>RABASys is temporarily unavailable</h1>
  <p>We are performing scheduled maintenance. Please try again later.</p>
</body>
</html>
HTML
        install -D -m 644 /dev/null "$MAINT_FLAG" \
            || fail "could not create maintenance flag"
        write_nginx_site
        if ! nginx -t || ! systemctl reload nginx; then
            fail "Nginx maintenance configuration failed"
        fi
        echo "MAINTENANCE: ON (Nginx is still running and returns HTTP 503)"
        ;;
    off)
        rm -f "$MAINT_FLAG" \
            || fail "could not remove maintenance flag"
        write_nginx_site
        if ! nginx -t || ! systemctl reload nginx; then
            fail "Nginx normal configuration failed"
        fi
        echo "MAINTENANCE: OFF (normal RABASys page is active)"
        ;;
    status)
        if [[ -f "$MAINT_FLAG" ]]; then
            echo "MAINTENANCE: ON"
        else
            echo "MAINTENANCE: OFF"
        fi
        ;;
    *)
        usage >&2
        exit 2
        ;;
esac

exit 0
