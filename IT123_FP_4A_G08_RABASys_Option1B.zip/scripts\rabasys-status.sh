#!/bin/bash
# Purpose: Report RABASys service, port, process, and disk status.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-status.sh [--help]
# AI assistance: OpenAI Codex, script structure, validation, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"

usage() {
    echo "Usage: sudo $0 [--help]"
    echo "Reports service state, listening port, process CPU/memory, and disk use."
    echo "Example: sudo $0"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this script as root"
[[ $# -eq 0 ]] || { usage >&2; exit 2; }

for required_command in systemctl ss grep ps df free top pgrep stat; do
    command -v "$required_command" >/dev/null 2>&1 \
        || fail "required command not found: $required_command"
done

[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"
# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"

: "${APP_DIR:?APP_DIR is required in the config}"
: "${APP_PORT:?APP_PORT is required in the config}"

echo "RABASys status"
echo "=============="

systemctl is-active --quiet "rabasys-backend.service"
service_status=$?

if [[ "$service_status" -eq 0 ]]; then
    echo "Backend service: RUNNING"
else
    echo "Backend service: NOT RUNNING"
fi

if ss -tlnp | grep -Eq ":${APP_PORT}([[:space:]]|$)" >/dev/null; then
    echo "Port $APP_PORT: LISTENING"
    port_status=0
else
    echo "Port $APP_PORT: NOT LISTENING"
    port_status=1
fi

app_pid="$(systemctl show -p MainPID --value "rabasys-backend.service" 2>/dev/null || true)"
if [[ -z "$app_pid" || "$app_pid" == "0" ]]; then
    app_pid="$(pgrep -f "$APP_DIR/backend/server.js" | head -n 1 || true)"
fi

if [[ -n "$app_pid" ]] && ps -p "$app_pid" >/dev/null 2>&1; then
    echo "Backend PID: $app_pid"
    ps -p "$app_pid" -o "pid=,ppid=,stat=,comm=,%cpu=,%mem=,etime="
else
    echo "Backend process: NOT FOUND"
fi

echo
echo "Disk usage for $APP_DIR:"
df -h "$APP_DIR"

echo
echo "Memory usage:"
free -h

echo
echo "CPU snapshot:"
top -b -n 1 | head -n 8

if [[ "$service_status" -ne 0 || "$port_status" -ne 0 ]]; then
    exit 1
fi

echo "STATUS: RABASys is running"
exit 0
