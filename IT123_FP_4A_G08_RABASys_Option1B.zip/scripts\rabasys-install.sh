#!/bin/bash
# Purpose: Install RABASys and its local PostgreSQL database on Ubuntu.
# Authors: BSIT IT 123 student
# Usage: sudo ./rabasys-install.sh [--help]
# AI assistance: OpenAI Codex, script structure, validation, and comments.

set -u
set -o pipefail

CONFIG_FILE="/etc/rabasys-toolkit.conf"

usage() {
    echo "Usage: sudo $0 [--help]"
    echo "Installs Nginx, Node.js, PostgreSQL, RABASys, and its local database."
    echo "Example: sudo $0"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
fi

[[ "$EUID" -eq 0 ]] || fail "run this installer as root"
command -v apt-get >/dev/null 2>&1 || fail "apt-get is required"
[[ -f "$CONFIG_FILE" ]] || fail "missing config file: $CONFIG_FILE"
[[ "$(stat -c '%a' "$CONFIG_FILE" 2>/dev/null)" == "600" ]] || fail "config must have mode 600"

# shellcheck source=/etc/rabasys-toolkit.conf
source "$CONFIG_FILE"

: "${SOURCE_DIR:?SOURCE_DIR is required in the config}"
: "${APP_DIR:?APP_DIR is required in the config}"
: "${DB_NAME:?DB_NAME is required in the config}"
: "${DB_USER:?DB_USER is required in the config}"
: "${DB_PASS:?DB_PASS is required in the config}"
: "${APP_USER:?APP_USER is required in the config}"
: "${APP_GROUP:?APP_GROUP is required in the config}"
: "${HEALTH_URL:?HEALTH_URL is required in the config}"

[[ -d "$SOURCE_DIR" ]] || fail "source directory not found: $SOURCE_DIR"
id "$APP_USER" >/dev/null 2>&1 || fail "Linux user not found: $APP_USER"
getent group "$APP_GROUP" >/dev/null 2>&1 || fail "Linux group not found: $APP_GROUP"

echo "Installing required Ubuntu packages..."
if ! apt-get update || ! apt-get install -y nginx nodejs npm postgresql postgresql-client; then
    fail "package installation failed"
fi

for required_command in systemctl curl tar psql npm node; do
    command -v "$required_command" >/dev/null 2>&1 \
        || fail "required command not found after installation: $required_command"
done

echo "Preparing application directory..."
install -d -o "$APP_USER" -g "$APP_GROUP" -m 755 "$APP_DIR"

echo "Copying application files without node_modules or old .env files..."
tar --exclude=node_modules --exclude=.env -cf - -C "$SOURCE_DIR" . \
    | tar -xf - -C "$APP_DIR" \
    || fail "application copy failed"

install -d -o "$APP_USER" -g "$APP_GROUP" -m 755 "$APP_DIR/backend" "$APP_DIR/frontend"

echo "Creating local PostgreSQL role and database..."
systemctl enable --now postgresql \
    || fail "could not start PostgreSQL"

sudo -u postgres psql --set=db_user="$DB_USER" --set=db_pass="$DB_PASS" --set=db_name="$DB_NAME" <<'SQL'
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'db_user', :'db_pass')
WHERE NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = :'db_user')\gexec

SELECT format('ALTER ROLE %I LOGIN PASSWORD %L', :'db_user', :'db_pass')
WHERE EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = :'db_user')\gexec

SELECT format('CREATE DATABASE %I OWNER %I', :'db_name', :'db_user')
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = :'db_name')\gexec
SQL

if [[ -f "$APP_DIR/backend/local-schema.sql" ]]; then
    PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
        -f "$APP_DIR/backend/local-schema.sql" \
        || fail "local schema import failed"
fi

cat > "$APP_DIR/backend/.env" <<EOF
NODE_ENV=production
PORT=${APP_PORT:-5000}
CLIENT_ORIGIN=http://localhost,http://127.0.0.1
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}
DB_POOL_MAX=10
JWT_SECRET=RABASysLocalJWTSecret2026ForStudentProjectOnly123456
RUN_SCHEMA=false
RUN_TRIP_REMINDERS=false
PAYMENT_GATEWAY=2C2P
TWOCP_TEST_MODE=true
TRUST_PROXY=false
EOF

echo "Installing Node.js dependencies and building frontend..."
(cd "$APP_DIR/backend" && npm install) || fail "backend dependency installation failed"
(cd "$APP_DIR/frontend" && npm install && npm run build) || fail "frontend build failed"

chown -R "$APP_USER:$APP_GROUP" "$APP_DIR"
chmod 600 "$APP_DIR/backend/.env"

cat > /etc/systemd/system/rabasys-backend.service <<EOF
[Unit]
Description=RABASys Node.js backend
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${APP_DIR}/backend
ExecStart=/usr/bin/node ${APP_DIR}/backend/server.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/nginx/sites-available/rabasys <<EOF
server {
    listen 80 default_server;
    server_name _;
    root ${APP_DIR}/frontend/dist;
    index index.html;

    location /api/ {
        proxy_pass http://127.0.0.1:${APP_PORT:-5000};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    location /uploads/ {
        proxy_pass http://127.0.0.1:${APP_PORT:-5000};
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF

ln -sf /etc/nginx/sites-available/rabasys /etc/nginx/sites-enabled/rabasys
rm -f /etc/nginx/sites-enabled/default

if ! systemctl daemon-reload \
    || ! systemctl enable --now rabasys-backend.service \
    || ! nginx -t \
    || ! systemctl reload nginx; then
    fail "service or Nginx setup failed"
fi

if curl --fail --silent --show-error "$HEALTH_URL" >/dev/null; then
    echo "SUCCESS: RABASys installed and health check passed: $HEALTH_URL"
    exit 0
else
    echo "FAILURE: RABASys installed, but health check failed: $HEALTH_URL" >&2
    exit 1
fi
